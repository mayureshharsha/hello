package com.pivotal.cf.broker.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

/**
 * The response from the broker sent back to the cloud controller 
 * on a successful service instance creation request
 * 
 * @author sgreenberg@gopivotal.com
 */
@JsonAutoDetect(getterVisibility = Visibility.NONE)
public class CreateServiceInstanceResponse {

	private ServiceInstance instance;
	
	public CreateServiceInstanceResponse() {}
	
	public CreateServiceInstanceResponse(ServiceInstance instance) {
		this.instance = instance;
	}
}
