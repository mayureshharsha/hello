package com.pivotal.cf.broker.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * Utility for encoding broker passwords to be configured in spring.
 * 
 * @author sgreenberg@gopivotal.com
 *
 */
public class PasswordEncoder {

	private static BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	
	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println( "ERROR - Usage: 'java com.pivotal.cf.broker.util.PasswordEncoder <password-to-encrypt>'");
			System.exit(1);
		} else {
			System.out.println(encoder.encode(args[0]));
		}
	}

}
